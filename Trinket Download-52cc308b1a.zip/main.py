print ("Welcome. Please log in!")
name = input ("What is your name?:")
password = input ("Type a password:")

while len(password)<4 or len(password)>4:
  print("Invalid Password.")
  password = input("Please re-enter password")

print("Valid poassword. Identification confirmed.")

choice = None

print("""
Welcome to the Recipe Program, """+name+"! Select the recipe you would like to make.")

print("""
    0 - Exit
    1 - Sushi
    2 - Bibimbap
    3 - Pork Dumpling
    """)
    
choice = int(input("Make your choice:")) 
    

while True:
 
    if choice == 1:
        print("You have decided to make Sushi")
        print ("""
|\    \ \ \ \ \ \ \      __   
|  \    \ \ \ \ \ \ \   | O~-_
|   >----|-|-|-|-|-|-|--|  __/
|  /    / / / / / / /   |__\  
|/     / / / / / / /
""")
        ssize=int(input("Please enter how many people the recipe is for:"))
        ricetotal=ssize
        sashimitotal=8*ssize
        soysaucetotal=5*ssize
        print("""
You will need:
            """)
        print(ricetotal,"bowl of rice")
        print(sashimitotal,"slice of Sashimi")
        print(soysaucetotal,"teaspoon soy sauce")
        
        print("""
Would you like to order more?
        """)
        answer = input("Your answer is:")
        if answer == "yes":
          choice = int(input("Make another choice:"))
        elif answer != "yes":
          print("See you next time")
          break
        
    elif choice ==2:
        print("You have decided to make Bibimbap")
        print("""
           |
         |  /
         | /
   .~^(,&|/o.
  |`-------^|
  \         /
   `======='    
   """)
        ssize=int(input("Please enter how many people the recipe is for:"))
        ricetotal=ssize
        eggtotal=ssize
        carrottotal=120*ssize
        mushroomtotal=100*ssize
        meattotla=100*ssize
        spinachtotal=100*ssize
        sesameoiltotol=ssize
        redpeppersauce=4*ssize
        
        print("""
You will need:
            """)
        print(ricetotal,"bowl of rice")
        print(eggtotal,"egg")
        print(carrottotal,"gram of carrot")
        print(mushroomtotal,"gram of mushroom")
        print(meattotla,"gram of meat")
        print(spinachtotal,"gram of spinachtotal")
        print(sesameoiltotol,"teaspoon oil")
        print(redpeppersauce,"teaspoon red peper sauce")
        print("""
Would you like to order more?
        """)
        answer = input("Your answer is:")
        if answer == "yes":
          choice = int(input("Make another choice:"))
        elif answer != "yes":
          print("See you next time")
          break
    elif choice ==3:
        print("You have decided to make Pork Dumpling")
        print("""            
     _                       _
    | |                     | (_)            
  __| |_   _ _ __ ___  _ __ | |_ _ __   __ _ 
 / _` | | | | '_ ` _ \| '_ \| | | '_ \ / _` |
| (_| | |_| | | | | | | |_) | | | | | | (_| |
 \__,_|\__,_|_| |_| |_| .__/|_|_|_| |_|\__, |
                      | |               __/ |
                      |_|              |___/ 
        """)
        
        ssize=int(input("Please enter how many people the recipe is for:"))
        dumplingwrappertotal=8*ssize
        cabbagetotal=ssize
        salttota=ssize
        groundporktotal=ssize
        scallionstotal=ssize
        soysaucetotal=3*ssize
        sesameoiltotol=2*ssize
        eggtotal=2*ssize  
         
        print("""
You will need:
            """)
        print(dumplingwrappertotal,"of dumpling wrapper")
        print(cabbagetotal,"pound of cabbage")
        print(salttota,"table spoon salt")
        print(groundporktotal,"pound of ground pork")
        print(scallionstotal,"bunch scallions, thinly sliced")
        print(soysaucetotal,"tablespoons soy sauce")
        print(sesameoiltotol,"tablespoons sesame oil")
        print(eggtotal,"egg")
        
        print("""
Would you like to order more? 
        """)
        answer = input("Your answer is:")
        if answer == "yes":
          choice = int(input("Make another choice:"))
        elif answer != "yes":
          print("See you next time")
          break

    elif choice == 0:
      print("see you next time")
      break

    else:
        print("This is an invalid response. Try again:")
        choice = int(input("Make your choice:"))

